/**
 * Copyright © Mcfyden ApS, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    deps: [
        'Magento_Search/js/custom',
        'Magento_Search/js/custom-search'
    ]
};
