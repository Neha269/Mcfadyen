/**
 * Copyright © Mcfyden ApS, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    deps: [
        'Magento_Catalog/js/gallery-slider',
        'Magento_Catalog/js/stick-content'
    ]
};